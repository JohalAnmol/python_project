# Online Store Discount Calculator with Invoice Saving

products = {
    "Laptop": 50000,
    "Phone": 25000,
    "Headphones": 1500,
    "Keyboard": 700,
    "Mouse": 400
}

cart = {}

def show_products():
    print("----- Available Products -----")
    for name, price in products.items():
        print(f"{name} - ₹{price}")

def add_to_cart():
    while True:
        item = input("\nEnter product name to add (or 'done' to finish): ").title()
        if item.lower() == "done":
            break
        elif item in products:
            qty = int(input(f"Enter quantity of {item}: "))
            if item in cart:
                cart[item] += qty
            else:
                cart[item] = qty
        else:
            print("Product not found. Please try again.")

def calculate_discount(total):
    if total < 1000:
        return 0
    elif total <= 5000:
        return 10
    elif total <= 10000:
        return 20
    else:
        return 30

def show_invoice():
    print("\n----- Invoice -----")
    invoice = []
    subtotal = 0
    for item, qty in cart.items():
        price = products[item]
        total_price = price * qty
        subtotal += total_price
        line = f"{item} x {qty} = ₹{total_price}"
        print(line)
        invoice.append(line)

    discount_percent = calculate_discount(subtotal)
    discount_amount = (discount_percent / 100) * subtotal
    final_amount = subtotal - discount_amount

    invoice.append("\n----- Final Bill -----")
    invoice.append(f"Subtotal         : ₹{subtotal:.2f}")
    invoice.append(f"Discount Applied : {discount_percent}%")
    invoice.append(f"Discount Amount  : ₹{discount_amount:.2f}")
    invoice.append(f"Total to Pay     : ₹{final_amount:.2f}")
    invoice.append("Thank you for shopping with us!")

    # Print and save to file
    for line in invoice:
        print(line)

    with open("invoice.txt", "w") as file:
        for line in invoice:
            file.write(line + "\n")

    print("\n✅ Invoice saved as 'invoice.txt'")

# Main Program
print("===== Welcome to the Online Store =====")
show_products()
add_to_cart()

if cart:
    show_invoice()
else:
    print("Cart is empty. No items purchased.")
