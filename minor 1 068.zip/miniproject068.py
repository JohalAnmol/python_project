# Online Store Discount Calculator with Product List

# Predefined products and prices
products = {
    "Laptop": 50000,
    "Phone": 25000,
    "Headphones": 1500,
    "Keyboard": 700,
    "Mouse": 400
}

cart = {}

print("----- Welcome to Online Store -----")
print("\nAvailable Products:")
for product, price in products.items():
    print(f"- {product}: ₹{price}")

# Add products to cart
while True:
    item = input("\nEnter product name to add (or 'done' to finish): ")
    if item.lower() == "done":
        break
    elif item in products:
        qty = int(input(f"Enter quantity of {item}: "))
        if item in cart:
            cart[item] += qty
        else:
            cart[item] = qty
    else:
        print("Product not found. Try again.")

# Calculate total
subtotal = 0
print("\n----- Invoice -----")
for item, qty in cart.items():
    price = products[item]
    total_price = price * qty
    subtotal += total_price
    print(f"{item} x {qty} = ₹{total_price}")

# Apply discount
if subtotal < 1000:
    discount_percent = 0
elif subtotal <= 5000:
    discount_percent = 10
elif subtotal <= 10000:
    discount_percent = 20
else:
    discount_percent = 30

discount_amount = (discount_percent / 100) * subtotal
final_price = subtotal - discount_amount

# Final Bill
print("\n----- Final Bill -----")
print(f"Subtotal         : ₹{subtotal:.2f}")
print(f"Discount Applied : {discount_percent}%")
print(f"Discount Amount  : ₹{discount_amount:.2f}")
print(f"Total to Pay     : ₹{final_price:.2f}")
print("Thank you for shopping with us!")
